#include<linux/kernel.h>
#include<stdarg.h>

asmlinkage long sys_maxminup(int n, ...){
	va_list nilai;
	va_start(nilai,n);
	int x;
	int i;
	int max = va_arg(nilai,int);
	int min = max;
	int before = max;
	int up = 0;
	for(i = 1;i<n;i++){
		x = va_arg(nilai,int);
		if(x > max){
			max = x;
		} else if (x < min){
			min = x;
		}
		if(x > before){
			up++;
		}
		before = x;
	}
	printk("Max = %d\nMin = %d\nUp =  %d\n",max,min,up);
	va_end(nilai);
	return 0;
}