#include<linux/kernel.h>

asmlinkage long sys_hworld (void) {
   printk("Hello, World!\n");
   return 0;
}
