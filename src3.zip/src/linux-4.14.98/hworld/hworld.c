#include<linux/kernel.h>

asmlinkage long sys_hworld (void) {
   printk("Hello, World!\n");
   printk("こんにちは、世界!\n");
   return 0;
}
