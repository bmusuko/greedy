#include<stdio.h>
#include<linux/kernel.h>
#include<sys/syscall.h>

int main(){
  long int test = syscall(333);
  printf("sys_hworld output : %ld\n",test);
  return 0;
}
