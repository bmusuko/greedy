#include<stdio.h>
#include<linux/kernel.h>
#include<sys/syscall.h>
#include<unistd.h>

int main(){
	long int test = syscall(333,5,1,7,2,6,3);
	printf("test = %ld\n",test);
	return 0;
}